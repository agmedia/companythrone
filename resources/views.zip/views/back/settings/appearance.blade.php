@extends('layouts.app')
@section('title', __('settings.appearance_title'))

@section('content')
    <livewire:settings.appearance />
@endsection
