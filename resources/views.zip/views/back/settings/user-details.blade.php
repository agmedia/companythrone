@extends('layouts.app')
@section('title', __('settings.details_title'))

@section('content')
    <livewire:settings.user-details />
@endsection
