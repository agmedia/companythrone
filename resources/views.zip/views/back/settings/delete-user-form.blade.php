@extends('layouts.app')
@section('title', __('settings.delete_account_title'))

@section('content')
    <livewire:settings.delete-user-form />
@endsection
