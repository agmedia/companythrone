<div class="alert alert-secondary">
    {{ __('back/shop/payments/cod.front_help') }}
</div>
