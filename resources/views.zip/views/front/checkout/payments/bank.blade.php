<div class="alert alert-secondary">
    {{ __('back/shop/payments/bank.front_help') }}
</div>
