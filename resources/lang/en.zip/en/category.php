<?php

return [
    'subcategories'  => 'Subcategories',
    'no_companies'   => 'No companies in this category yet.',
    'company_count'  => '{0} 0 companies|{1} 1 company|[2,*] :count companies',
];