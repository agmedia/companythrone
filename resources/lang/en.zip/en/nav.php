<?php

return [
    'home' => 'Home',
    'add_company' => 'Add your company',
];