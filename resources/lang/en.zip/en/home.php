<?php

return [
    'title' => 'Companythrone – business catalog',
    'headline' => 'Increase your website traffic',
    'subtitle' => 'Boost visits, grow your network and stay visible in daily searches.',
    'featured' => 'Featured companies',
    'search_companies' => 'Search companies',
    'view_all' => 'View all',
];